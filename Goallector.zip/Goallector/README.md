# Goallector
목표 달성 프로젝트

### 프로젝트 실행 방법
```
# 개발 환경
docker-compose -f docker-compose.dev.yml up

# 배포 환경
docker-copmose -f docker-compose.prod.yml up
```

- 달력
> [참고 사이트](https://alvarotrigo.com/blog/css-calendar/)