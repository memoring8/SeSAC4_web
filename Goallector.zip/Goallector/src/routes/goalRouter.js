const express = require("express");
const ctr = require("../controller/goalController");
const router = express.Router();

module.exports = router;