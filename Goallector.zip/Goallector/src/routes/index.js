const router = {
    MAIN: '/',
    USER: '/user',
    GOAL: '/goal'
};
module.exports = router;