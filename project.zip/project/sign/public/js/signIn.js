'use strict';

const id = document.querySelector('#id');
const pw = document.querySelector('#pw');
const signInBtn = document.querySelector('.btn')

signInBtn.addEventListener('click', signIn_check);
function signIn_check(){
    if(id.value) {
        
    }
}