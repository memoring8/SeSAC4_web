'use strict';

// comment
const postCommentInFeed = () => {
  const commentInput = document.getElementById('post_comment_input');
  const commentPostBtn = document.getElementsByClassName('post_comment_btn')[0];

  // 댓글 입력시 요소 생성
  const addNewComment = () => {
    const newCommentLocation = document.getElementsByClassName('comment_list')[0];
    const newComment = document.createElement('li');

    newComment.innerHTML = `
      <div class="user_desc">
        <em>iAmUser</em>
        <span>${commentInput.value}</span>
      </div>
      <button><i class="far fa-heart fa-xs"></i></button>
    `;

    newCommentLocation.appendChild(newComment);
    commentInput.value = '';
  }


  // 사용자 입력 들어올 시, 게시 버튼 활성화
  commentInput.addEventListener('keyup', () => {
    commentInput.value ? commentPostBtn.style.opacity = '1' : commentPostBtn.style.opacity = '.3';
    if (window.event.keyCode === 13 && commentInput.value) {
      addNewComment();
    }
  });

  // 댓글 게시
  commentPostBtn.addEventListener('click', () => {
    if (commentInput.value) {
      addNewComment();
    } else {
      alert('댓글이 입력되지 않았습니다 😳');
    }
  })
}


postCommentInFeed();


// 
// 
// 
// calendar 
// // test
// let today = new Date();
// let currentMonth = today.getMonth();
// let currentYear = todat.getFullYear();

// let months = [
//   'Jan',
//   'Feb',
//   'Mar',
//   'Apr',
//   'May',
//   'Jun',
//   'Jul',
//   'Aug',
//   'Sep',
//   'Oct',
//   'Nov',
//   'Dec'
// ];

// let monthAndYear = document.querySelector('.cal-nav');

// showCalendar(currentMonth, currentYear);

// function showCalendar(month, year) {
//   let firstDay = new Date(year, month).getDay();
//   let dayIn = 32 - new Date(year, month, 32).getDate();

//   let tbl = document.querySelector('.cal-body');

//   tbl.innerHTML = "";

//   for(let i = 0; i < 6; i++) {
//     let row = document.createElement('tr');

//     for(let j = 0; j < 7; j++) {
//       if(i === 0 && j < firstDay) {
//         let cell = document.createElement('td');
//         let cellText = document.createTextNode('');

//         cell.appendChild(cellText);
//         row.appendChild(cell);
//       }
//       date++;
//     }
//     tbl.appendChild(row);
//   }
// }


// function previous() {
//   currentYear = (currentMonth === 0) ?
// }






// // 달력 출력하기

var currentTitle = document.getElementsByClassName('cal-nav');
var calendarBody = document.getElementsByClassName('cal-body');
var today = new Date();
var first = new Date(today.getFullYear(), today.getMonth(),0);
var monthList = ['January','February','March','April','May','June','July','August','September','October','November','December'];
var leapYear=[31,29,31,30,31,30,31,31,30,31,30,31];
var notLeapYear=[31,28,31,30,31,30,31,31,30,31,30,31];
var pageFirst = first;
var pageYear;
if(first.getFullYear() % 4 === 0){
    pageYear = leapYear;
}else{
    pageYear = notLeapYear;
}

function showCalendar(){
    let monthCnt = 100;
    let cnt = 1;
    for(var i = 0; i < 6; i++){
        var $tr = document.createElement('tr');
        $tr.setAttribute('id', monthCnt);   
        for(var j = 0; j < 7; j++){
            if((i === 0 && j < first.getDay()) || cnt > pageYear[first.getMonth()]){
                var $td = document.createElement('td');
                $tr.appendChild($td);     
            }else{
                var $td = document.createElement('td');
                $td.textContent = cnt;
                $td.setAttribute('id', cnt);                
                $tr.appendChild($td);
                cnt++;
            }
        }
        monthCnt++;
        calendarBody.appendChild($tr);
    }
}
showCalendar();

function removeCalendar(){
    let catchTr = 100;
    for(var i = 100; i< 106; i++){
        var $tr = document.getElementById(catchTr);
        $tr.remove();
        catchTr++;
    }
}