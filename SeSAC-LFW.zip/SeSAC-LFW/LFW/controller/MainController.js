const models = require("../model");

exports.main_index = (req, res) => {
    res.render("login");
}

